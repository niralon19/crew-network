import json
import types
import pytest

from noc_crewai.models import Alert, Finding, Evidence, InvestigationReport, SummaryItem
from noc_crewai.memory.store import IncidentStore
from noc_crewai.main import handle_alert

class DummyJira:
    def __init__(self):
        self.created = []
    def create_issue(self, **kwargs):
        self.created.append(kwargs)
        return {"key": "OPS-1"}

@pytest.fixture
def store(tmp_path):
    return IncidentStore(str(tmp_path / "mem.db"))

def test_flow_new_incident(monkeypatch, store):
    # Mock build_agents to avoid real CrewAI/LLM
    def fake_build_agents():
        return {
            "coatr": object(),
            "traffic": object(),
            "coupling": object(),
            "summary": object(),
            "options": object(),
        }

    # Router deterministic
    monkeypatch.setattr("noc_crewai.main.build_agents", fake_build_agents)

    # Mock domain investigation to return deterministic finding/evidence
    def fake_run_domain_investigation(alert, route, agent):
        return (
            Finding(agent=route, finding="DB pool exhausted", confidence="high"),
            Evidence(logs=["pool exhausted"], metrics={"error_rate": 7.2}, sql={"rowcount": 1}),
        )
    monkeypatch.setattr("noc_crewai.main.run_domain_investigation", fake_run_domain_investigation)

    # Mock build_report to avoid LLM
    def fake_build_report(**kwargs):
        return InvestigationReport(
            investigation_summary=[
                SummaryItem(
                    step=1,
                    agent="coatr",
                    check="domain_investigation",
                    observation="DB pool exhausted",
                    interpretation="db_connections_saturated",
                )
            ],
            fact_tags=["severity:critical", "type:coatr", "signal:db_pool_exhausted"],
            things_to_consider=["Validate DB connection pool sizing vs workload"],
        )
    monkeypatch.setattr("noc_crewai.main.build_report", fake_build_report)

    # Mock publish_to_jira to avoid requests
    def fake_publish_to_jira(alert, report, jira):
        return "OPS-1"
    monkeypatch.setattr("noc_crewai.main.publish_to_jira", fake_publish_to_jira)

    alert = Alert(
        id="a1", type="coatr", service="coatr-api", description="err", severity="critical",
        timestamp="2025-12-22T00:00:00Z", metadata={}
    )
    result = handle_alert(alert, store=store, jira=DummyJira())

    assert result["memory"]["result"] == "new_incident"
    assert result["memory"]["jira_key"] == "OPS-1"

def test_flow_duplicate(monkeypatch, store):
    # Same mocks as above
    def fake_build_agents():
        return {"coatr": object(), "traffic": object(), "coupling": object(), "summary": object(), "options": object()}
    monkeypatch.setattr("noc_crewai.main.build_agents", fake_build_agents)

    def fake_run_domain_investigation(alert, route, agent):
        return (Finding(agent=route, finding="DB pool exhausted", confidence="high"), Evidence())
    monkeypatch.setattr("noc_crewai.main.run_domain_investigation", fake_run_domain_investigation)

    def fake_build_report(**kwargs):
        return InvestigationReport(
            investigation_summary=[],
            fact_tags=["severity:critical", "type:coatr", "signal:db_pool_exhausted"],
            things_to_consider=[],
        )
    monkeypatch.setattr("noc_crewai.main.build_report", fake_build_report)
    monkeypatch.setattr("noc_crewai.main.publish_to_jira", lambda a,r,j: "OPS-1")

    alert1 = Alert(id="a1", type="coatr", service="coatr-api", description="err", severity="critical",
                   timestamp="2025-12-22T00:00:00Z", metadata={})
    alert2 = Alert(id="a2", type="coatr", service="coatr-api", description="err2", severity="critical",
                   timestamp="2025-12-22T00:05:00Z", metadata={})

    r1 = handle_alert(alert1, store=store, jira=DummyJira())
    r2 = handle_alert(alert2, store=store, jira=DummyJira())

    assert r1["memory"]["result"] == "new_incident"
    assert r2["memory"]["result"] == "duplicate"
    assert r2["memory"]["jira_key"] == "OPS-1"
