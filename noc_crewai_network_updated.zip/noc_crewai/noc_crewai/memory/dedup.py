from datetime import datetime
from .fingerprint import compute_fingerprint
from .store import IncidentStore
from ..models import Alert, InvestigationReport

def process_report_with_memory(
    *,
    store: IncidentStore,
    alert: Alert,
    report: InvestigationReport,
    jira_key: str | None,
) -> dict:
    signature = "|".join(report.fact_tags or [])
    fingerprint = compute_fingerprint(alert.service, alert.type, signature)

    existing = store.get(fingerprint)
    if existing:
        store.touch(fingerprint)
        return {
            "result": "duplicate",
            "fingerprint": fingerprint,
            "jira_key": existing["jira_key"],
        }

    store.create(
        fingerprint=fingerprint,
        service=alert.service,
        alert_type=alert.type,
        root_cause=signature or "no_facts",
        jira_key=jira_key,
    )
    return {
        "result": "new_incident",
        "fingerprint": fingerprint,
        "jira_key": jira_key,
    }
