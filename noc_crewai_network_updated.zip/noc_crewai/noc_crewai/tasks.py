from .crewai_shim import Task

def domain_task(agent, alert, route: str) -> Task:
    return Task(
        agent=agent,
        description=f"""
        You are handling a production alert.

        Route: {route}
        Alert ID: {alert.id}
        Service: {alert.service}
        Severity: {alert.severity}
        Description: {alert.description}
        Metadata: {alert.metadata}

        Use ONLY your available tools to gather evidence.
        Provide a concise finding and confidence.
        Return JSON with fields: finding, confidence, evidence (metrics/logs/sql).
        """,
        expected_output="JSON with finding/confidence/evidence"
    )


def summary_task(agent, steps_json: str) -> Task:
    """LLM converts raw step outputs into a consistent, human-readable summary.

    IMPORTANT: this task must not infer root cause or suggest actions.
    """

    return Task(
        agent=agent,
        description=f"""
You are given a JSON list of investigation steps (checks) and their raw results.

Input JSON:
{steps_json}

Output STRICT JSON array. Each item MUST have exactly these keys:
  step, agent, check, observation, interpretation

Rules:
  - observation: a factual restatement of the raw result.
  - interpretation: a light explanation of what the observation indicates.
  - Do NOT infer a root cause.
  - Do NOT recommend actions.
  - Do NOT add extra keys.
  - If a step result is empty, use observation="no_data" and interpretation="insufficient_data".
""",
        expected_output="Strict JSON array of summary items",
    )


def options_task(agent, *, fact_tags_json: str, allowed_options_json: str) -> Task:
    """LLM selects relevant options from an explicit allowed list."""

    return Task(
        agent=agent,
        description=f"""
You are given:
  1) FACT_TAGS (JSON array of strings)
  2) ALLOWED_OPTIONS (JSON array of strings)

FACT_TAGS:
{fact_tags_json}

ALLOWED_OPTIONS:
{allowed_options_json}

Output STRICT JSON array of strings.

Rules:
  - Each string MUST be an EXACT element from ALLOWED_OPTIONS.
  - Do NOT invent options.
  - Do NOT rephrase.
  - If none apply, output []
""",
        expected_output="Strict JSON array of selected allowed options",
    )
