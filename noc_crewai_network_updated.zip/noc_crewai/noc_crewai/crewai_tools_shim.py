"""Wrapper for the CrewAI @tool decorator.

When CrewAI is installed, we use its decorator so tools are discoverable by
agents. When it's not installed, we expose a no-op decorator so imports work.
"""

from __future__ import annotations

from typing import Callable, TypeVar

F = TypeVar("F", bound=Callable[..., object])


try:  # pragma: no cover
    from crewai.tools import tool as _tool  # type: ignore

    # CrewAI's decorator supports both @tool and @tool("name").
    def tool(arg=None):
        return _tool(arg)

except Exception:  # pragma: no cover

    def tool(arg=None):
        """No-op decorator that supports both @tool and @tool('name')."""

        if callable(arg):
            return arg

        def _decorator(fn: F) -> F:
            return fn

        return _decorator
