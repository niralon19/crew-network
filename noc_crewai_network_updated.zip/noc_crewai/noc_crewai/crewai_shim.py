"""Thin wrapper around CrewAI imports.

This repo is meant to run with CrewAI installed. However, unit tests and static
analysis should be able to import the package even when CrewAI isn't available
(e.g., CI environments without external internet access).

If CrewAI is missing, we provide minimal stubs that fail fast on execution.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, List, Optional


try:  # pragma: no cover
    from crewai import Agent, Task, Crew  # type: ignore
except Exception:  # pragma: no cover
    @dataclass
    class Agent:  # minimal stub
        role: str
        goal: str
        backstory: str = ""
        tools: Optional[List[Callable[..., Any]]] = None
        verbose: bool = False

    @dataclass
    class Task:  # minimal stub
        agent: Any
        description: str
        expected_output: str = ""

    class Crew:  # minimal stub
        def __init__(self, agents: list[Any], tasks: list[Any], verbose: bool = False):
            self.agents = agents
            self.tasks = tasks
            self.verbose = verbose

        def kickoff(self):
            raise RuntimeError(
                "CrewAI is not installed. Install dependencies (pip install crewai) to run the pipeline."
            )
