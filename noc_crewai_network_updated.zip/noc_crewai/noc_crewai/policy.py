from __future__ import annotations

import os
from .models import Alert


def should_open_jira_for_alert(alert: Alert) -> bool:
    """Deterministic gating for side effects.

    Keep this *non-LLM*.
    """

    # Hard override
    force = os.getenv("ALWAYS_OPEN_JIRA", "0").strip().lower() in ("1", "true", "yes")
    if force:
        return True

    if alert.severity == "critical":
        return True
    if alert.severity == "warning":
        return True
    return False
