from .crewai_shim import Agent
from .tools.traffic import check_traffic
from .tools.metrics import check_ratios
from .tools.logs import analyze_logs
from .tools.db import run_sql

def build_agents():
    traffic_agent = Agent(
        role="Traffic Integrity Specialist",
        goal="Verify traffic integrity and detect anomalies",
        backstory="Senior NOC engineer specializing in network traffic analysis",
        tools=[check_traffic],
        verbose=True,
    )

    coupling_agent = Agent(
        role="Coupling & Ratios Specialist",
        goal="Validate system ratios and percentage-based metrics",
        backstory="SRE focused on SLIs, ratios, and drift detection",
        tools=[check_ratios],
        verbose=True,
    )

    coatr_agent = Agent(
        role="Application & DB Specialist",
        goal="Investigate application issues using logs and SQL",
        backstory="Backend engineer with deep observability experience",
        tools=[analyze_logs, run_sql],
        verbose=True,
    )

    summary_agent = Agent(
        role="Investigation Summary Specialist",
        goal="Produce factual investigation summaries with light interpretation only",
        backstory=(
            "Senior operations engineer. You narrate what checks were performed and "
            "what was observed, with minimal interpretation. You never infer root cause "
            "and you never recommend actions."
        ),
        verbose=True,
    )

    options_agent = Agent(
        role="Operational Options Selector",
        goal="Select relevant items from an allowed list of operational considerations",
        backstory=(
            "Operations assistant. You only select from a provided list of allowed "
            "considerations (no rephrasing, no invention)."
        ),
        verbose=True,
    )

    return {
        "traffic": traffic_agent,
        "coupling": coupling_agent,
        "coatr": coatr_agent,
        "summary": summary_agent,
        "options": options_agent,
    }
