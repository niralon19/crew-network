from __future__ import annotations

import json
import re
from .crewai_shim import Crew

from .models import Alert, Evidence, Finding, InvestigationStep, InvestigationReport, SummaryItem
from .tasks import summary_task, options_task


def compute_fact_tags(alert: Alert, finding: Finding, evidence: Evidence) -> list[str]:
    """Derive deterministic tags from the evidence.

    These tags are used for memory dedup and for gating which "allowed options" we let the LLM pick from.
    Keep this logic deterministic and testable.
    """

    tags: set[str] = set()

    # Alert-level
    tags.add(f"severity:{alert.severity}")
    tags.add(f"type:{alert.type}")

    # Finding-level (very light normalization)
    finding_text = (finding.finding or "").lower()
    if "timeout" in finding_text:
        tags.add("signal:timeout")
    if "5xx" in finding_text or "error" in finding_text:
        tags.add("signal:error_rate")
    if "pool" in finding_text and ("exhaust" in finding_text or "full" in finding_text):
        tags.add("signal:db_pool_exhausted")

    # Evidence metrics
    m = evidence.metrics or {}
    if isinstance(m.get("error_rate"), (int, float)) and float(m["error_rate"]) >= 1.0:
        tags.add("metric:error_rate_high")
    if isinstance(m.get("latency_p95_ms"), (int, float)) and float(m["latency_p95_ms"]) >= 1000:
        tags.add("metric:latency_high")
    if isinstance(m.get("db_pool_used_pct"), (int, float)) and float(m["db_pool_used_pct"]) >= 95:
        tags.add("metric:db_pool_util_high")
    if isinstance(m.get("rps"), (int, float)) and float(m["rps"]) > 0:
        # A generic hint; thresholds should be tuned per service.
        tags.add("metric:traffic_present")

    # Evidence logs (cheap keyword scan, avoid heavy parsing)
    joined_logs = "\n".join(evidence.logs or []).lower()
    if "connection pool" in joined_logs or "pool" in joined_logs and "exhaust" in joined_logs:
        tags.add("log:db_pool_exhausted")
    if "deadlock" in joined_logs:
        tags.add("log:db_deadlock")
    if "out of memory" in joined_logs or "oom" in joined_logs:
        tags.add("log:oom")
    if re.search(r"\b5\d\d\b", joined_logs):
        tags.add("log:http_5xx")

    # Evidence SQL
    sql = evidence.sql or {}
    if "rowcount" in sql and isinstance(sql.get("rowcount"), int) and sql["rowcount"] > 0:
        tags.add("sql:rows_returned")

    # Make stable ordering for downstream.
    return sorted(tags)


def allowed_options_for_tags(tags: list[str]) -> list[str]:
    """Explicit allow-list. Anything not in this list cannot be returned by the LLM."""

    options: list[str] = []

    # Generic operational hygiene (safe defaults)
    options += [
        "Verify alert threshold calibration and noise",
        "Confirm impact scope (single service vs multi-service)",
        "Correlate with recent deployments/config changes",
        "Check for upstream dependency issues",
    ]

    # Traffic-related
    if "metric:traffic_present" in tags:
        options += [
            "Check rate limiting / throttling configuration",
            "Validate autoscaling policies for traffic spikes",
        ]

    # Error/5xx related
    if "signal:error_rate" in tags or "metric:error_rate_high" in tags or "log:http_5xx" in tags:
        options += [
            "Inspect error budget/SLI dashboards for regressions",
            "Look for exception fingerprints in application logs",
        ]

    # DB pool
    if "signal:db_pool_exhausted" in tags or "metric:db_pool_util_high" in tags or "log:db_pool_exhausted" in tags:
        options += [
            "Validate DB connection pool sizing vs workload",
            "Check for connection leaks (open connections over time)",
            "Review slow queries / query plan regressions",
        ]

    # OOM
    if "log:oom" in tags:
        options += [
            "Validate memory limits/requests and GC behavior",
            "Check for memory leak patterns and heap growth",
        ]

    # Deduplicate while keeping order
    seen: set[str] = set()
    out: list[str] = []
    for o in options:
        if o not in seen:
            seen.add(o)
            out.append(o)
    return out


def build_report(
    *,
    alert: Alert,
    finding: Finding,
    evidence: Evidence,
    summary_agent,
    options_agent,
) -> InvestigationReport:
    """Build the final report.

    LLM is used only for:
      - Turning raw step outputs into a human summary
      - Selecting relevant items from an allow-list
    """

    steps = [
        InvestigationStep(
            step=1,
            agent=finding.agent,
            check="domain_investigation",
            result={
                "finding": finding.finding,
                "confidence": finding.confidence,
                "evidence": evidence.model_dump(),
            },
        )
    ]
    steps_json = json.dumps([s.model_dump() for s in steps], ensure_ascii=False)

    # 1) LLM summary of performed checks
    summary_crew = Crew(agents=[summary_agent], tasks=[summary_task(summary_agent, steps_json)], verbose=True)
    raw_summary = summary_crew.kickoff()

    summary_items: list[SummaryItem] = []
    try:
        data = json.loads(str(raw_summary))
        summary_items = [SummaryItem(**item) for item in data]
    except Exception:
        # Never break pipeline on reporting.
        summary_items = [
            SummaryItem(
                step=1,
                agent=finding.agent,
                check="domain_investigation",
                observation=str(finding.finding),
                interpretation="insufficient_data",
            )
        ]

    # 2) Deterministic fact tags
    fact_tags = compute_fact_tags(alert, finding, evidence)

    # 3) Allow-list + LLM selection
    allowed_options = allowed_options_for_tags(fact_tags)
    fact_tags_json = json.dumps(fact_tags, ensure_ascii=False)
    allowed_options_json = json.dumps(allowed_options, ensure_ascii=False)

    options_crew = Crew(
        agents=[options_agent],
        tasks=[options_task(options_agent, fact_tags_json=fact_tags_json, allowed_options_json=allowed_options_json)],
        verbose=True,
    )
    raw_options = options_crew.kickoff()

    things_to_consider: list[str] = []
    try:
        selected = json.loads(str(raw_options))
        # Guardrail: hard filter only allowed options.
        things_to_consider = [o for o in selected if o in allowed_options]
    except Exception:
        things_to_consider = []

    return InvestigationReport(
        investigation_summary=summary_items,
        fact_tags=fact_tags,
        things_to_consider=things_to_consider,
    )
