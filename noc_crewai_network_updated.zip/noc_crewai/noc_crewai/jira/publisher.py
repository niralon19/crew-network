from ..models import Alert, InvestigationReport
from ..policy import should_open_jira_for_alert
from .formatter import format_description
from .client import JiraClient

PRIORITY_MAP = {
    "P0": "Highest",
    "P1": "High",
    "P2": "Medium",
}

def publish_to_jira(alert: Alert, report: InvestigationReport, jira: JiraClient) -> str | None:
    if not should_open_jira_for_alert(alert):
        return None

    # Map severity to Jira priority (tune for your org)
    priority = "Highest" if alert.severity == "critical" else "High" if alert.severity == "warning" else "Medium"
    labels = ["ai-incident", f"service-{alert.service.lower()}"]

    description = format_description(alert, report)
    issue = jira.create_issue(
        summary=f"[{alert.service}] {alert.type} alert"[:240],
        description=description,
        issue_type="Task",
        priority=priority,
        labels=labels,
    )
    return issue.get("key")
